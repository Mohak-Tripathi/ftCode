#!/bin/bash
cd $(dirname $0)
sudo mv DEMOTESTING.js /home/pi4/DBEDGE/client/